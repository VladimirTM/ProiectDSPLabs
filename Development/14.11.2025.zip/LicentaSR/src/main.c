#include <lpc22xx.h>
#include <FreeRTOS.h>
#include <task.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "log.h"

/* I2C Slave Configuration */
#define I2C_SLAVE_ADDR  0x50  // 7-bit slave address

/* I2C Slave Status Codes */
#define I2C_STAT_OWN_SLA_W_ACK      0x60  // Own SLA+W received, ACK returned
#define I2C_STAT_ARB_LOST_SLA_W     0x68  // Arbitration lost, Own SLA+W received
#define I2C_STAT_SLA_W_DATA_ACK     0x80  // Data received after SLA+W, ACK returned
#define I2C_STAT_SLA_W_DATA_NACK    0x88  // Data received after SLA+W, NACK returned
#define I2C_STAT_STOP_REPEAT        0xA0  // STOP or repeated START received
#define I2C_STAT_OWN_SLA_R_ACK      0xA8  // Own SLA+R received, ACK returned
#define I2C_STAT_ARB_LOST_SLA_R     0xB0  // Arbitration lost, Own SLA+R received
#define I2C_STAT_SLA_R_DATA_ACK     0xB8  // Data transmitted, ACK received
#define I2C_STAT_SLA_R_DATA_NACK    0xC0  // Data transmitted, NACK received
#define I2C_STAT_SLA_R_LAST_ACK     0xC8  // Last data transmitted, ACK received

#define RX_BUFFER_SIZE 64
#define TX_BUFFER_SIZE 64

/* I2C Slave State Machine States */
typedef enum
{
    I2C_SLAVE_STATE_IDLE,
    I2C_SLAVE_STATE_RECEIVE_ADDR,
    I2C_SLAVE_STATE_RECEIVE_DATA,
    I2C_SLAVE_STATE_TRANSMIT_DATA,
    I2C_SLAVE_STATE_PROCESS_RX,
    I2C_SLAVE_STATE_ERROR
} I2C_Slave_State_t;

/* I2C Slave Context */
typedef struct
{
    I2C_Slave_State_t state;
    uint8_t rxBuffer[RX_BUFFER_SIZE];
    uint8_t txBuffer[TX_BUFFER_SIZE];
    uint8_t rxIndex;
    uint8_t txIndex;
    uint8_t rxCount;
    uint8_t txCount;
    uint8_t dataReady;
    uint8_t txReady;
    uint32_t errorCount;
} I2C_Slave_Context_t;

/* Global context */
I2C_Slave_Context_t i2cSlaveContext = {0};

void vApplicationStackOverflowHook(TaskHandle_t xTask, char* pcTaskName)
{
    LOG_SERIAL("Stack overflow for task: %s\r\n", pcTaskName);
}

void vApplicationMallocFailedHook(void)
{
    unsigned int i = 0;
    while (1)
    {
        IO0SET = 1u << 30;
        for (i = 0; i < 100000; i++);
        IO0CLR = 1u << 30;
        for (i = 0; i < 100000; i++);
    }
}



void set_pll(void)
{
    PLLCON = 0x01;
    PLLCFG = 0x23;
    PLLFEED = 0xAA;
    PLLFEED = 0x55;
    while ((PLLSTAT & (1 << 10)) == 0);
    PLLCON = 0x03;
    PLLFEED = 0xAA;
    PLLFEED = 0x55;
    VPBDIV = 0;
}

/* Initialize I2C as slave */
void I2C_Slave_Init(void)
{
    // Configure pins for I2C (P0.2 = SCL, P0.3 = SDA)
    PINSEL0 |= (1 << 4) | (1 << 6);

    // Set I2C clock (100kHz)
    I2SCLH = 0x14;
    I2SCLL = 0x14;

    // Set slave address (7-bit address in bits 7:1)
    I2ADR = (I2C_SLAVE_ADDR << 1);

    // Clear and enable I2C
    I2CONCLR = 0x000000FF;
    I2CONSET = 0x00000040; // Enable I2C interface
    I2CONSET = 0x00000004; // Assert ACK flag

    // Initialize slave context
    memset(&i2cSlaveContext, 0, sizeof(I2C_Slave_Context_t));
    i2cSlaveContext.state = I2C_SLAVE_STATE_IDLE;
    i2cSlaveContext.dataReady = 0;
    i2cSlaveContext.txReady = 0;
}

/* State Handlers */
void I2C_Slave_HandleIdleState(I2C_Slave_Context_t *ctx)
{
    uint8_t stat = I2STAT;

    switch (stat)
    {
        case I2C_STAT_OWN_SLA_W_ACK:      // Own SLA+W received
        case I2C_STAT_ARB_LOST_SLA_W:     // Arbitration lost, Own SLA+W received
            ctx->state = I2C_SLAVE_STATE_RECEIVE_ADDR;
            ctx->rxIndex = 0;
            ctx->dataReady = 0;
            I2CONSET = 0x04; // Assert ACK
            break;

        case I2C_STAT_OWN_SLA_R_ACK:      // Own SLA+R received
        case I2C_STAT_ARB_LOST_SLA_R:     // Arbitration lost, Own SLA+R received
            ctx->state = I2C_SLAVE_STATE_TRANSMIT_DATA;
            ctx->txIndex = 0;
            // Send first byte immediately
            if (ctx->txReady && ctx->txIndex < ctx->txCount)
            {
                I2DAT = ctx->txBuffer[ctx->txIndex++];
            }
            else
            {
                I2DAT = 0xFF; // No data available
            }
            I2CONSET = 0x04;
            break;

        default:
            I2CONSET = 0x04;
            break;
    }

    // Clear interrupt flag
    if (stat != 0xF8)
    {
        I2CONCLR = 0x08;
    }
}

void I2C_Slave_HandleReceiveAddrState(I2C_Slave_Context_t *ctx)
{
    uint8_t stat = I2STAT;

    switch (stat)
    {
        case I2C_STAT_SLA_W_DATA_ACK:     // Data received, ACK returned
            ctx->state = I2C_SLAVE_STATE_RECEIVE_DATA;
            if (ctx->rxIndex < RX_BUFFER_SIZE)
            {
                ctx->rxBuffer[ctx->rxIndex++] = I2DAT;
                I2CONSET = 0x04; // ACK next byte
            }
            else
            {
                I2CONCLR = 0x04; // Buffer full, NACK
            }
            break;

        case I2C_STAT_STOP_REPEAT:        // STOP or repeated START received
            ctx->rxCount = ctx->rxIndex;
            ctx->dataReady = 1;
            ctx->state = I2C_SLAVE_STATE_PROCESS_RX;
            I2CONSET = 0x04;
            break;

        default:
            I2CONSET = 0x04;
            break;
    }

    // Clear interrupt flag
    if (stat != 0xF8)
    {
        I2CONCLR = 0x08;
    }
}

void I2C_Slave_HandleReceiveDataState(I2C_Slave_Context_t *ctx)
{
    uint8_t stat = I2STAT;

    switch (stat)
    {
        case I2C_STAT_SLA_W_DATA_ACK:     // Data received, ACK returned
            if (ctx->rxIndex < RX_BUFFER_SIZE)
            {
                ctx->rxBuffer[ctx->rxIndex++] = I2DAT;
                I2CONSET = 0x04; // ACK next byte
            }
            else
            {
                I2CONCLR = 0x04; // Buffer full, NACK
            }
            break;

        case I2C_STAT_SLA_W_DATA_NACK:    // Data received, NACK returned
            if (ctx->rxIndex < RX_BUFFER_SIZE)
            {
                ctx->rxBuffer[ctx->rxIndex++] = I2DAT;
            }
            I2CONSET = 0x04;
            break;

        case I2C_STAT_STOP_REPEAT:        // STOP or repeated START received
            ctx->rxCount = ctx->rxIndex;
            ctx->dataReady = 1;
            ctx->state = I2C_SLAVE_STATE_PROCESS_RX;
            I2CONSET = 0x04;
            break;

        default:
            I2CONSET = 0x04;
            break;
    }

    // Clear interrupt flag
    if (stat != 0xF8)
    {
        I2CONCLR = 0x08;
    }
}

void I2C_Slave_HandleTransmitDataState(I2C_Slave_Context_t *ctx)
{
    uint8_t stat = I2STAT;

    switch (stat)
    {
        case I2C_STAT_SLA_R_DATA_ACK:     // Data transmitted, ACK received
            if (ctx->txReady && ctx->txIndex < ctx->txCount)
            {
                I2DAT = ctx->txBuffer[ctx->txIndex++];
            }
            else
            {
                I2DAT = 0xFF; // No data available
            }
            I2CONSET = 0x04;
            break;

        case I2C_STAT_SLA_R_DATA_NACK:    // Data transmitted, NACK received
        case I2C_STAT_SLA_R_LAST_ACK:     // Last data transmitted
            ctx->state = I2C_SLAVE_STATE_IDLE;
            ctx->txIndex = 0;
            I2CONSET = 0x04;
            break;

        default:
            I2CONSET = 0x04;
            break;
    }

    // Clear interrupt flag
    if (stat != 0xF8)
    {
        I2CONCLR = 0x08;
    }
}

void I2C_Slave_HandleProcessRxState(I2C_Slave_Context_t *ctx)
{
    if (ctx->rxCount > 0)
    {
        // Process received character
        uint8_t receivedChar = ctx->rxBuffer[0];
        LOG_SERIAL("Received character: %c (0x%02X)\r\n", receivedChar, receivedChar);

        // Optionally prepare response
        // ctx->txBuffer[0] = receivedChar;  // Echo back
        // ctx->txCount = 1;
        // ctx->txReady = 1;
    }

    ctx->state = I2C_SLAVE_STATE_IDLE;
}

void I2C_Slave_HandleErrorState(I2C_Slave_Context_t *ctx)
{
    ctx->errorCount++;

    // Reset I2C if too many errors
    if (ctx->errorCount > 10)
    {
        I2CONCLR = 0x000000FF;
        I2CONSET = 0x00000040; // Enable I2C interface
        I2CONSET = 0x00000004; // Assert ACK flag
    }

    ctx->state = I2C_SLAVE_STATE_IDLE;
}

/* Main I2C Slave Task */
void I2C_Slave_Process(I2C_Slave_Context_t *ctx)
{
    switch (ctx->state)
    {
        case I2C_SLAVE_STATE_IDLE:
            I2C_Slave_HandleIdleState(ctx);
            break;

        case I2C_SLAVE_STATE_RECEIVE_ADDR:
            I2C_Slave_HandleReceiveAddrState(ctx);
            break;

        case I2C_SLAVE_STATE_RECEIVE_DATA:
            I2C_Slave_HandleReceiveDataState(ctx);
            break;

        case I2C_SLAVE_STATE_TRANSMIT_DATA:
            I2C_Slave_HandleTransmitDataState(ctx);
            break;

        case I2C_SLAVE_STATE_PROCESS_RX:
            I2C_Slave_HandleProcessRxState(ctx);
            break;

        case I2C_SLAVE_STATE_ERROR:
            I2C_Slave_HandleErrorState(ctx);
            break;

        default:
            ctx->state = I2C_SLAVE_STATE_IDLE;
            break;
    }
}

/* Set data to transmit when master reads */
void I2C_Slave_SetTxData(uint8_t* data, uint8_t len)
{
    if (len > TX_BUFFER_SIZE)
        len = TX_BUFFER_SIZE;

    memcpy(i2cSlaveContext.txBuffer, data, len);
    i2cSlaveContext.txCount = len;
    i2cSlaveContext.txIndex = 0;
    i2cSlaveContext.txReady = 1;
}

/* I2C Slave Task */
void I2CSlaveTask(void)
{
    I2C_Slave_Process(&i2cSlaveContext);
}

void I2CSlaveTaskWrapper(void* pvParameters)
{
    for (;;)
    {
        IO1SET = 1u << 21;
        I2CSlaveTask();
        IO1CLR = 1u << 21;
        vTaskDelay(FREERTOS_US_TO_TICK(100));
    }
}

/* Main function */
int main(void)
{
    // Set PLL and clocks
    set_pll();
    MAMCR = 2;
    MAMTIM = 4;

    // Init Debug LED (P1.21 output)
    PINSEL1 &= ~((1 << 16) | (1 << 17));
    IO1DIR |= (1 << 21);

    // Initialize I2C as slave
    I2C_Slave_Init();

    // Initialize logging
    LOG_init();

    LOG_SERIAL("I2C Slave initialized at address 0x%02X\r\n", I2C_SLAVE_ADDR);

    // Optionally prepare initial transmit data
    uint8_t initData[] = "ACK";
    I2C_Slave_SetTxData(initData, sizeof(initData) - 1);

    // Create I2C Slave task
    xTaskCreate(I2CSlaveTaskWrapper, "I2CSlave", 200, NULL, 7, (TaskHandle_t*)NULL);

    // Start scheduler
    vTaskStartScheduler();

    while (1);

    return 0;
}