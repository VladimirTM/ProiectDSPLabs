//
// Created by valy on 14.04.2025.
//

#ifndef DEMO_TASK_H
#define DEMO_TASK_H

#include <stdint.h>

/* Sensor Data Structure */
typedef struct
{
    int16_t accelX, accelY, accelZ;
    int16_t temperature;
    int16_t gyroX, gyroY, gyroZ;
    float accelX_g, accelY_g, accelZ_g;      // Acceleration in g
    float temp_C;                             // Temperature in Celsius
    float gyroX_dps, gyroY_dps, gyroZ_dps;   // Angular velocity in deg/s
} MPU6050_Data_t;

/* I2C State Machine States */
typedef enum
{
    I2C_STATE_IDLE,

    /* Initialize Sensor States */
    I2C_STATE_START_INIT,
    I2C_STATE_SEND_ADDR_WRITE_INIT,
    I2C_STATE_SEND_REG_INIT,
    I2C_STATE_SEND_DATA_INIT,
    I2C_STATE_STOP_INIT,

    /* Sensor Read States */
    I2C_STATE_START_READ,
    I2C_STATE_SEND_ADDR_WRITE_READ,
    I2C_STATE_SEND_REG_READ,
    I2C_STATE_RESTART_READ,
    I2C_STATE_SEND_ADDR_READ_READ,
    I2C_STATE_WAIT_DATA_READ,
    I2C_STATE_READ_DATA,

    I2C_STATE_PROCESS_DATA,
    I2C_STATE_ERROR
} I2C_State_t;

/* I2C Task Context */
typedef struct
{
    I2C_State_t state;
    uint8_t sensorInitialized;
    uint8_t rawData[14];        // Buffer for all sensor data (14 bytes total)
    uint8_t dataIndex;
    MPU6050_Data_t sensorData;
    uint32_t errorCount;
} I2C_Context_t;

/* Global context */
extern I2C_Context_t i2cContext;

void I2C1_Init(void);
void I2C_HandleIdleState(I2C_Context_t *ctx);
void I2C_HandleStartInitState(I2C_Context_t *ctx);
void I2C_HandleSendAddrWriteInitState(I2C_Context_t *ctx);
void I2C_HandleSendRegInitState(I2C_Context_t *ctx);
void I2C_HandleSendDataInitState(I2C_Context_t *ctx);
void I2C_HandleStopInitState(I2C_Context_t *ctx);
void I2C_HandleStartReadState(I2C_Context_t *ctx);
void I2C_HandleSendAddrWriteReadState(I2C_Context_t *ctx);
void I2C_HandleSendRegReadState(I2C_Context_t *ctx);
void I2C_HandleRestartReadState(I2C_Context_t *ctx);
void I2C_HandleSendAddrReadReadState(I2C_Context_t *ctx);
void I2C_HandleWaitDataReadState(I2C_Context_t *ctx);
void I2C_HandleReadDataState(I2C_Context_t *ctx);
void I2C_HandleProcessDataState(I2C_Context_t *ctx);
void I2C_HandleErrorState(I2C_Context_t *ctx);

void MyDemoTask(void);

#endif //DEMO_TASK_H
