//
// Created by valy on 14.04.2025.
//

#ifndef DEMO_TASK_H
#define DEMO_TASK_H
void MyDemoTask(void);
#endif //DEMO_TASK_H
