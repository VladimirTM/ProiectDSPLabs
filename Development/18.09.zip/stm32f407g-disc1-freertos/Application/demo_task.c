//
// Created by valy on 14.04.2025.
//

#include "demo_task.h"

#include <stdio.h>
#include <stdint.h>
#include "main.h"
#include "stm32f4xx_hal_gpio.h"
#include "usbd_cdc_if.h"

// void GPIO_Init(void)
// {
// 	RCC->AHB1ENR |= 1UL<<1; //Enable GPIOB clock
// 	GPIOB->MODER |= ( (2UL<<(6*2)) | (2UL<<(7*2)) );  // Configuring PB6 and PB7 in Alternate function
// 	GPIOB->PUPDR |= ( (1UL<<(6*2)) | (1UL<<(7*2))); // Selecting PB6 and PB7 as Pull up pins
// 	GPIOB->OTYPER |= ( (1UL<<6) | (1UL<<7) );  // Setting PB6 and PB7 as open drain
// 	GPIOB->OSPEEDR |= ( (2UL<<(6*2)) | (2UL<<(7*2)) ); // Setting PB6 and PB7 at high speed
// 	GPIOB->AFR[0] |= ( (4UL<<(6*4)) | (4UL)<<(7*4)); // Selecting the Alternate function (AF4)
// }
//
// void I2C_Init(void)
// {
// 	RCC->APB1ENR |= 1UL<<21; // Enable I2C1 clock
// 	I2C1->CR1 |= 1UL<<15; // Reset I2C
// 	I2C1->CR1 &= ~(1UL<<15); // Reset I2C
// 	I2C1->CR2 |= 16UL<<0; // Set I2C clock at 16MHz
// 	I2C1->OAR1 |= 1UL<<14; // Needs to be set high by software for I2C
// 	I2C1->CCR |= 0x14UL<<0; // Set SCl at 400KHz
// 	I2C1->TRISE |= 5UL<<0; // Configure rise time as 250ns (4 + 1)
// 	I2C1->CR1 |= 1UL<<0; // Enable I2C1
// }
//
// void I2C_Start(void)
// {
// 	I2C1->CR1 |= 1UL<<10; // Enable the acknowledgment ACK bit
// 	I2C1->CR1 |= 1UL<<8; // Set the START bit to Start Communication
// 	while(!(I2C1->SR1 & I2C_SR1_SB));  // SB bit is set when START condition is generated
// }
//
// uint8_t temp;
//
// void I2C_Send_Address(uint8_t address)
// {
// 	I2C1->DR = address; //Put the address to be sent into the I2C_DR register
// 	while(!(I2C1->SR1 & I2C_SR1_ADDR)); // ADDR bit is polled in the I2C_SR1 register for end of address transmission
// 	temp = (I2C1->SR1 | I2C1->SR2); // Variable that will read I2C_SR1 and I2C_SR2 for clearing the ADDR bit
// }
//
// void I2C_Write(uint8_t data)
// {
// 	while(!(I2C1->SR1 & I2C_SR1_TXE));  // Polling the TxE bit in the I2C_SR1 register to see if data register is empty
// 	I2C1->DR = data; // Put the data to be written in the I2C_DR register
// 	while(!(I2C1->SR1 & I2C_SR1_BTF)); // Poll the BTF (Byte Transfer Finished) bit in the I2C_SR1 register to confirm Byte transfer
// }
//
// uint8_t result;
//
// void I2C_Read(uint8_t data)
// {
// 	while(!(I2C1->SR1 & I2C_SR1_RXNE)); // Polling the RxNE bit in the I2C_SR1 register to see if data register is not empty
// 	result = I2C1->DR; // Read the data from thr I2C_DR register
// 	while(!(I2C1->SR1 & I2C_SR1_BTF)); // Poll the BTF (Byte Transfer Finished) bit in the I2C_SR1 register to confirm Byte transfer
// }
//
// void I2C_Stop()
// {
// 	I2C1->CR1 |= 1UL<<9; // Stop Communication after current byte transfer
// }

void MyDemoTask(void)
{
	static uint32_t n = 0;
	static char text[1000];
	if (n % 2)
	{
		HAL_GPIO_WritePin(GPIOD, LD4_Pin|LD3_Pin|LD5_Pin|LD6_Pin, GPIO_PIN_RESET);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOD, LD4_Pin|LD3_Pin|LD5_Pin|LD6_Pin, GPIO_PIN_SET);
	}
	n++;

	sprintf (text,"Hello %d\n", n);
	CDC_Transmit_FS(text,strlen(text));
}
