#include <lpc22xx.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "serial.h"
#include "mpu6050.h"

/*
- refactorizare
- o functie de init de structuri de date+ i2c ( nu face nici o tranzactie)
- taskuri
   - automat de stari general - NOT_INIT, CONFIGURING, IDLE
		- 2 moduri de functionare - (1) burst - citeste continuu + salvare date in memorie in ceva structura
														o functie de genul get_data(DATA *data)
																(2) on demand - 
																			o fcuntie de cerere() - la primul apel (request) - return OK_LATER - urmat. apeluri (in caz ca nu e gata inca) - am date
   - functie de configurare burst/on demand
   - fucntie de trigger de reinit
	 - reglat sensibilitati date de user + default puse de noi
*/
	
void initI2C(void)
{
	PINSEL0 |= (1 << 4) | (1 << 6); // I2C
	I2CONSET = 0x40; // enable I2C
	I2SCLH = 0x14;
	I2SCLL = 0x14;
}

void initInterrupts(void)
{
	VICIntEnable |= 1 << 4;
	VICIntSelect |= 1 << 4;
}

void initTimer(void)
{
	T0TCR = 0x02;
	T0MR0 = 100;
	T0MCR |= (3 << 0);
	T0TCR = 0x01;
}

void initDriver(void)
{
	initUART();
	initI2C();
	initInterrupts();
	startSensor();
	initTimer();
}

__irq void irq_handler(void)
{	
	if(doneInit == 0) // initializare
	{
		pollingWrite(regDat[2 * cntWrite], regDat[2 * cntWrite + 1]);
	}
	else // citire
	{
		if(cntRead <= lenRead)
		{
			IO1SET = 1u << 20;
			pollingRead(0x3B);
		}
		else {
			processMeasurements(measurements, results);
			IO1CLR = 1u << 20;
			//printResults(results);
			cntRead = 0;
			startSensor();
		}
	}
	T0IR |= 1;
	VICVectAddr = 0x00000000;
}

void delay_seconds(int seconds)
{
	volatile unsigned int i = 0;
	for (i = 0; i < 1474560 * seconds; i++);
}

int main(void)
{
	PINSEL1 &= ~((1 << 29) | ( 1 << 28 ));
	PINSEL0 |= 5;
	IO0DIR |= 1 << 30; //P0.30 output
	PINSEL1 &= ~((1 << 16) | ( 1 << 17 ));
	IO1DIR |= (1 << 20); //P1.20 output
	delay_seconds(5);
	initDriver();
	while(1)
	{
	}
	return 0;
}
