#include <lpc22xx.h>
#include <FreeRTOS.h>
#include <serial.h>
#include <task.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "log.h"

void vApplicationStackOverflowHook( TaskHandle_t xTask, char * pcTaskName )
{
	LOG_SERIAL("Stack overflow for task: %s\r\n", pcTaskName);
}

void vApplicationMallocFailedHook( void )
{
	unsigned int i = 0;
	while (1)
	{
		IO0SET = 1u << 30;
		for (i = 0; i < 100000; i++);
		IO0CLR = 1u << 30;
		for (i = 0; i < 100000; i++);
	}
}

void TaskTest1(void *pvParameters)
{
	static unsigned int n = 0;
	for (;;)
	{
		n++;
		if (n % 2)
		{
			IO0SET = 1u << 30;
		}
		else
		{
			IO0CLR = 1u << 30;
		}
		vTaskDelay(500);
	}
}

void set_pll(void)
{
	PLLCON = 0x01;
	PLLCFG = 0x23;
	PLLFEED = 0xAA;
	PLLFEED = 0x55;
	while ((PLLSTAT & (1 << 10)) == 0);
	PLLCON = 0x03;
	PLLFEED = 0xAA;
	PLLFEED = 0x55;
	VPBDIV = 0;
}

void MyTask()
{
	LOG_SERIAL("MyTask\r\n");
}

void MyTaskWrapper(void *pvParameters)
{
	for (;;)
	{
		MyTask();
		vTaskDelay(FREERTOS_MS_TO_TICK(1000));
	}
}

volatile uint8_t wai = 0, donewai = 0;

void WhoAmITask()
{
	switch(I2STAT)
	{
	case 0x08: // start
		{
			I2DAT = 0xD0;
			I2CONCLR = 0x20;
			I2CONSET = 0x04;
			break;
		}
	case 0x10: // repeated start
		{
			I2DAT = 0xD1;
			I2CONCLR = 0x20;
			I2CONSET = 0x04;
			break;
		}
	case 0x18: // enter data
		{
			I2DAT = 0x75;
			break;
		}
	case 0x20: // NACK received
		{
			I2CONSET = 0x14;
			break;
		}
	case 0x28: // data sent with ACK
		{
			I2CONSET = 0x20;
			//I2CONSET = 0x10;
			break;
		}
	case 0x30: // data sent with NACK
		{
			I2CONSET = 0x14;
			break;
		}
	case 0x40: // address received with ACK
		{
			I2CONSET = 0x04;
			break;
		}
	case 0x48: //  address received with NACK
		{
			I2CONSET = 0x20;
			break;
		}
	case 0x50: // data received with ACK
		{
			wai = I2DAT;
			I2CONSET = 0x10;
			donewai = 1;
			break;
		}
	case 0x58: // data received with NACK
		{
			wai = I2DAT;
			I2CONSET = 0x10;
			donewai = 1;
			break;
		}
	}
	if (I2STAT != 0xF8)
	{
		I2CONCLR = 0x08;
	}
}

void WhoAmITaskWrapper(void *pvParameters)
{
	for (;;)
	{
		WhoAmITask();
		if (donewai == 1)
		{
			LOG_SERIAL("%x", wai);
			I2CONCLR = 0x000000FF;
			I2CONSET = 0x00000040;
			I2CONSET = 0x00000020;
			donewai = 0;
		}
		vTaskDelay(FREERTOS_MS_TO_TICK(100));
	}
}

int main(void)
{
	volatile int a = 4;
	set_pll();

	MAMCR = 2;
	MAMTIM = 4;

	PINSEL1 &= ~((1 << 29) | ( 1 << 28 ));
	PINSEL0 |= 5;
	IO0DIR |= 1 << 30; //P0.30 output
	PINSEL0 |= (1 << 4) | (1 << 6); // I2C
	PINSEL0 &= ~(1 << 7);
	I2CONSET = 0x40;
	I2SCLH = 0x28;
	I2SCLL = 0x28;
	I2CONCLR = 0x000000FF;
	I2CONSET = 0x00000040;
	I2CONSET = 0x00000020;
	LOG_init();

	xTaskCreate( TaskTest1, "Test1", 100, NULL, 2, ( TaskHandle_t * ) NULL );
	xTaskCreate(WhoAmITaskWrapper, "WAI", 500, NULL, 2,  ( TaskHandle_t * ) NULL);
	vTaskStartScheduler();
	//

	while(1);

	return 0;
}


