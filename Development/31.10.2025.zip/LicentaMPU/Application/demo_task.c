//
// Created by valy on 14.04.2025.
//

#include "demo_task.h"

#include <stdio.h>
#include "main.h"
#include "stm32f4xx_hal_gpio.h"
#include "usbd_cdc_if.h"

/* MPU6050 Register Definitions */
#define MPU6050_ADDR            0x68
#define MPU6050_PWR_MGMT_1      0x6B
#define MPU6050_ACCEL_XOUT_H    0x3B

/* I2C1 Base Address */
#define I2C1_BASE               0x40005400UL
#define I2C1                    ((I2C_TypeDef *) I2C1_BASE)

/* I2C CR1 Bits */
#define I2C_CR1_PE              (1 << 0)
#define I2C_CR1_START           (1 << 8)
#define I2C_CR1_STOP            (1 << 9)
#define I2C_CR1_ACK             (1 << 10)
#define I2C_CR1_SWRST           (1 << 15)

/* I2C SR1 Bits */
#define I2C_SR1_SB              (1 << 0)
#define I2C_SR1_ADDR            (1 << 1)
#define I2C_SR1_BTF             (1 << 2)
#define I2C_SR1_TXE             (1 << 7)
#define I2C_SR1_RXNE            (1 << 6)

/* Global context */
I2C_Context_t i2cContext = {0};

/* Initialize I2C1 peripheral using registers */
void I2C1_Init(void)
{
    /* Enable clocks for GPIOB and I2C1 */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

    /* Configure PB6 (SCL) and PB7 (SDA) as AF4 (I2C1) */
    GPIOB->MODER &= ~(GPIO_MODER_MODER6 | GPIO_MODER_MODER7);
    GPIOB->MODER |= (GPIO_MODER_MODER6_1 | GPIO_MODER_MODER7_1);

    /* Set to open-drain */
    GPIOB->OTYPER |= (GPIO_OTYPER_OT6 | GPIO_OTYPER_OT7);

    /* Set to high speed */
    GPIOB->OSPEEDR |= (GPIO_OSPEEDER_OSPEEDR6 | GPIO_OSPEEDER_OSPEEDR7);

    /* Set to pull-up */
    GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPDR6 | GPIO_PUPDR_PUPDR7);
    GPIOB->PUPDR |= (GPIO_PUPDR_PUPDR6_0 | GPIO_PUPDR_PUPDR7_0);

    /* Set alternate function to AF4 (I2C1) */
    GPIOB->AFR[0] &= ~(0xF << (6 * 4) | 0xF << (7 * 4));
    GPIOB->AFR[0] |= (4 << (6 * 4) | 4 << (7 * 4));

    /* Reset I2C1 */
    I2C1->CR1 |= I2C_CR1_SWRST;
    I2C1->CR1 &= ~I2C_CR1_SWRST;

    /* Configure I2C1: Standard Mode 100kHz */
    I2C1->CR2 = 42;
    I2C1->CCR = 210;
    I2C1->TRISE = 43;

    /* Enable I2C1 */
    I2C1->CR1 |= I2C_CR1_PE;
}

/* I2C Low-Level Functions */
void I2C1_Start(void)
{
    I2C1->CR1 |= I2C_CR1_START;
}

void I2C1_Stop(void)
{
    I2C1->CR1 |= I2C_CR1_STOP;
}

void I2C1_SendAddress(uint8_t address, uint8_t direction)
{
    I2C1->DR = (address << 1) | direction;
}

void I2C1_SendData(uint8_t data)
{
    I2C1->DR = data;
}

uint8_t I2C1_CheckStart(void)
{
    return (I2C1->SR1 & I2C_SR1_SB) ? 1 : 0;
}

uint8_t I2C1_CheckAddr(void)
{
    if(I2C1->SR1 & I2C_SR1_ADDR)
    {
        (void)I2C1->SR1;
        (void)I2C1->SR2;
        return 1;
    }
    return 0;
}

uint8_t I2C1_CheckTXE(void)
{
    return (I2C1->SR1 & I2C_SR1_TXE) ? 1 : 0;
}

uint8_t I2C1_CheckBTF(void)
{
    return (I2C1->SR1 & I2C_SR1_BTF) ? 1 : 0;
}

uint8_t I2C1_CheckRXNE(void)
{
    return (I2C1->SR1 & I2C_SR1_RXNE) ? 1 : 0;
}

uint8_t I2C1_ReadData(void)
{
    return I2C1->DR;
}

void I2C1_SetAck(uint8_t enable)
{
    if(enable)
        I2C1->CR1 |= I2C_CR1_ACK;
    else
        I2C1->CR1 &= ~I2C_CR1_ACK;
}

/* Data Processing Function */
void MPU6050_ProcessData(I2C_Context_t *ctx)
{
    /* Extract 16-bit values from raw data buffer */
    /* MPU6050 sends data as: ACCEL_X_H, ACCEL_X_L, ACCEL_Y_H, ACCEL_Y_L, ACCEL_Z_H, ACCEL_Z_L */
    ctx->sensorData.accelX = (int16_t)((ctx->rawData[0] << 8) | ctx->rawData[1]);
    ctx->sensorData.accelY = (int16_t)((ctx->rawData[2] << 8) | ctx->rawData[3]);
    ctx->sensorData.accelZ = (int16_t)((ctx->rawData[4] << 8) | ctx->rawData[5]);

    /* Temperature: TEMP_H, TEMP_L */
    ctx->sensorData.temperature = (int16_t)((ctx->rawData[6] << 8) | ctx->rawData[7]);

    /* Gyroscope: GYRO_X_H, GYRO_X_L, GYRO_Y_H, GYRO_Y_L, GYRO_Z_H, GYRO_Z_L */
    ctx->sensorData.gyroX = (int16_t)((ctx->rawData[8] << 8) | ctx->rawData[9]);
    ctx->sensorData.gyroY = (int16_t)((ctx->rawData[10] << 8) | ctx->rawData[11]);
    ctx->sensorData.gyroZ = (int16_t)((ctx->rawData[12] << 8) | ctx->rawData[13]);

    /* Convert to physical units */
    /* Accelerometer: ±2g range, sensitivity = 16384 LSB/g */
    ctx->sensorData.accelX_g = ctx->sensorData.accelX / 16384.0f;
    ctx->sensorData.accelY_g = ctx->sensorData.accelY / 16384.0f;
    ctx->sensorData.accelZ_g = ctx->sensorData.accelZ / 16384.0f;

    /* Temperature: Formula from datasheet */
    /* Temp_degC = (TEMP_OUT / 340) + 36.53 */
    ctx->sensorData.temp_C = (ctx->sensorData.temperature / 340.0f) + 36.53f;

    /* Gyroscope: ±250°/s range, sensitivity = 131 LSB/(°/s) */
    ctx->sensorData.gyroX_dps = ctx->sensorData.gyroX / 131.0f;
    ctx->sensorData.gyroY_dps = ctx->sensorData.gyroY / 131.0f;
    ctx->sensorData.gyroZ_dps = ctx->sensorData.gyroZ / 131.0f;
}

/* State Handlers */
void I2C_HandleIdleState(I2C_Context_t *ctx)
{
    /* Initialize sensor if not done */
    if(!ctx->sensorInitialized)
    {
        ctx->state = I2C_STATE_START_INIT;
    }
    else
    {
        /* Read sensor data */
        ctx->dataIndex = 0;
        ctx->state = I2C_STATE_START_READ;
    }
}

/* Sensor Initialization States */
void I2C_HandleStartInitState(I2C_Context_t *ctx)
{
    I2C1_Start();
    ctx->state = I2C_STATE_SEND_ADDR_WRITE_INIT;
}

void I2C_HandleSendAddrWriteInitState(I2C_Context_t *ctx)
{
    if(I2C1_CheckStart())
    {
        I2C1_SendAddress(MPU6050_ADDR, 0);
        ctx->state = I2C_STATE_SEND_REG_INIT;
    }
}

void I2C_HandleSendRegInitState(I2C_Context_t *ctx)
{
    if(I2C1_CheckAddr())
    {
        if(I2C1_CheckTXE())
        {
            I2C1_SendData(MPU6050_PWR_MGMT_1);
            ctx->state = I2C_STATE_SEND_DATA_INIT;
        }
    }
}

void I2C_HandleSendDataInitState(I2C_Context_t *ctx)
{
    if(I2C1_CheckTXE())
    {
        I2C1_SendData(0x00);  // Wake up sensor (clear sleep bit)
        ctx->state = I2C_STATE_STOP_INIT;
    }
}

void I2C_HandleStopInitState(I2C_Context_t *ctx)
{
    if(I2C1_CheckBTF())
    {
        I2C1_Stop();
        ctx->sensorInitialized = 1;
        GPIOD->ODR |= GPIO_ODR_OD12;  // Green LED ON
        ctx->state = I2C_STATE_IDLE;
    }
}

/* Sensor Read States (reads all 14 bytes: Accel + Temp + Gyro) */
void I2C_HandleStartReadState(I2C_Context_t *ctx)
{
    GPIOB->ODR ^= GPIO_ODR_OD9;
    I2C1_Start();
    ctx->state = I2C_STATE_SEND_ADDR_WRITE_READ;
}

void I2C_HandleSendAddrWriteReadState(I2C_Context_t *ctx)
{
    if(I2C1_CheckStart())
    {
        I2C1_SendAddress(MPU6050_ADDR, 0);
        ctx->state = I2C_STATE_SEND_REG_READ;
    }
}

void I2C_HandleSendRegReadState(I2C_Context_t *ctx)
{
    if(I2C1_CheckAddr())
    {
        if(I2C1_CheckTXE())
        {
            /* Start reading from ACCEL_XOUT_H - all data is sequential */
            I2C1_SendData(MPU6050_ACCEL_XOUT_H);
            ctx->state = I2C_STATE_RESTART_READ;
        }
    }
}

void I2C_HandleRestartReadState(I2C_Context_t *ctx)
{
    if(I2C1_CheckBTF())
    {
        I2C1_Start();
        ctx->state = I2C_STATE_SEND_ADDR_READ_READ;
    }
}

void I2C_HandleSendAddrReadReadState(I2C_Context_t *ctx)
{
    if(I2C1_CheckStart())
    {
        I2C1_SendAddress(MPU6050_ADDR, 1);
        ctx->state = I2C_STATE_WAIT_DATA_READ;
    }
}

void I2C_HandleWaitDataReadState(I2C_Context_t *ctx)
{
    if(I2C1_CheckAddr())
    {
        /* Enable ACK for multi-byte read */
        I2C1_SetAck(1);
        ctx->state = I2C_STATE_READ_DATA;
    }
}

void I2C_HandleReadDataState(I2C_Context_t *ctx)
{
    if(I2C1_CheckRXNE())
    {
        ctx->rawData[ctx->dataIndex++] = I2C1_ReadData();

        /* Check if this is the second-to-last byte */
        if(ctx->dataIndex == 13)
        {
            /* Disable ACK before last byte */
            I2C1_SetAck(0);
            I2C1_Stop();
        }

        /* Check if all 14 bytes received */
        if(ctx->dataIndex >= 14)
        {
            GPIOB->ODR ^= GPIO_ODR_OD9;
            ctx->state = I2C_STATE_PROCESS_DATA;
        }
    }
}

void I2C_HandleProcessDataState(I2C_Context_t *ctx)
{
    static char buffer[100];

    /* Process all sensor data */
    MPU6050_ProcessData(ctx);

    /* Format sensor data into buffer */
    snprintf(buffer, sizeof(buffer),
             "Acc:%.2f,%.2f,%.2f Gyro:%.1f,%.1f,%.1f T:%.1fC\n",
             ctx->sensorData.accelX_g,
             ctx->sensorData.accelY_g,
             ctx->sensorData.accelZ_g,
             ctx->sensorData.gyroX_dps,
             ctx->sensorData.gyroY_dps,
             ctx->sensorData.gyroZ_dps,
             ctx->sensorData.temp_C);

    /* Send data via USB CDC */
    CDC_Transmit_FS((uint8_t*)buffer, strlen(buffer));

    /* Toggle blue LED to show data is being read */
    GPIOD->ODR ^= GPIO_ODR_OD15;

    ctx->state = I2C_STATE_IDLE;
}

void I2C_HandleErrorState(I2C_Context_t *ctx)
{
    ctx->errorCount++;
    I2C1_Stop();

    if(ctx->errorCount > 10)
    {
        I2C1->CR1 |= I2C_CR1_SWRST;
        I2C1->CR1 &= ~I2C_CR1_SWRST;
        I2C1->CR1 |= I2C_CR1_PE;

        ctx->sensorInitialized = 0;
    }

    GPIOD->ODR ^= GPIO_ODR_OD14;   // Red LED toggle
    ctx->state = I2C_STATE_IDLE;
}

void MyDemoTask(void)
{
    static uint32_t n = 0;
    static char text[1000];
    if (n % 2)
    {
        HAL_GPIO_WritePin(GPIOD, LD4_Pin | LD3_Pin | LD5_Pin | LD6_Pin, GPIO_PIN_RESET);
    }
    else
    {
        HAL_GPIO_WritePin(GPIOD, LD4_Pin | LD3_Pin | LD5_Pin | LD6_Pin, GPIO_PIN_SET);
    }
    n++;

    sprintf(text, "Hello %d\n", n);
    CDC_Transmit_FS(text, strlen(text));
}
