#include <lpc22xx.h>
#include <stdint.h>
#include <string.h>

void initI2C(void)
{
	PINSEL0 |= (1 << 4) | (1 << 6); // I2C
	I2CONSET = 0x40; // enable I2C
	I2SCLH = 0x64;
	I2SCLL = 0x64;
}

void startI2C(void)
{
	I2CONSET = 0x20;
	while((I2CONSET & 0x08) == 0);
	I2CONCLR = 0x28;
}

void stopI2C(void)
{
	I2CONSET = 0x50;
}

void writeI2C(char data)
{
	I2DAT = data;
	I2CONSET = 0x40;
	while((I2CONSET & 0x08) == 0);
	I2CONCLR = 0x08;
}

unsigned char readACK(void)
{
	I2CONSET = 0x44;
	while( (I2CONSET & 0x08) == 0 );
	I2CONCLR = 0x0C;
	return I2DAT;
}

unsigned char readNACK(void)
{
	I2CONSET = 0x40;
	while( (I2CONSET & 0x08) == 0 );
	I2CONCLR = 0x08;
	return I2DAT;
}
